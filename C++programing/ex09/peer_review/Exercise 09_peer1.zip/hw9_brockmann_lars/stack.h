#ifndef STACK_H
#define STACK_H

#include <iostream>
#include <array>

#define m_maxElements 10

template <class T>
class Stack
{
public:
    Stack(): m_top(-1),m_array({}){};
    void push(T value)
    {
        if(isFull()){
            std::cout << "Push:  " << value << " --> Stack full" << std::endl;

        }else{
            std::cout << "Push:  " << value << std:: endl;
            m_top++;
            m_array[m_top]=value;
        }
    }
    T pop(){

        if(isEmpty()){
            std::cout << "Pop: --> Stack empty" << std::endl;
            return {};

        }else{
            T returnElement = m_array[m_top];
            std::cout << "Pop: --> " << returnElement << std:: endl;
            m_array[m_top] = {};
            m_top--;
            return returnElement;
        }
    }

    T peek(){
        if(isEmpty()){
            std::cout << "Peek: --> Stack empty" << std::endl;
            return {};

        }else{
            T topElement = m_array[m_top];
            std::cout << "Peek: --> " << topElement << std:: endl;
            return topElement;
        }

    };

    void print(){
        std::cout << "Print:";
        for(int i=m_maxElements-1;i>=0;i--){
            std::cout << "[" << m_array[i] << "],";
        }
        std::cout << std::endl;
    }

private:
    int m_top;
    T topElement();
    bool isFull()
    {
        if (m_top == (m_maxElements - 1))
            return 1;
        else
            return 0;
    }
    bool isEmpty()
    {
        if (m_top == -1)
            return 1;
        else
            return 0;
    }
    std::array<T,m_maxElements> m_array;
};

#endif // STACK_H
