#include <iostream>
#include "stack.h"

int main()
{
    Stack<int> intStack;
    intStack.push(1);
    intStack.push(2);
    intStack.push(3);
    intStack.push(4);
    intStack.push(5);
    intStack.push(6);
    intStack.push(7);
    intStack.push(8);
    intStack.push(9);
    intStack.push(10);
    intStack.push(11);

    intStack.print();
    intStack.pop();
    intStack.print();
    intStack.peek();
    intStack.print();

    std::cout << "--------------------------" << std::endl;

    Stack<double> doubleStack;
    doubleStack.push(1.1);
    doubleStack.push(1.2);
    doubleStack.push(1.3);
    doubleStack.print();
    doubleStack.pop();
    doubleStack.pop();
    doubleStack.pop();
    doubleStack.pop();
    doubleStack.print();
    doubleStack.peek();
    doubleStack.print();

    std::cout << "--------------------------" << std::endl;


    Stack<std::string> strStack;
    strStack.push("one");
    strStack.push("two");
    strStack.push("three");
    strStack.print();
    strStack.pop();
    strStack.print();
    strStack.peek();
    strStack.print();
    return 0;
}
