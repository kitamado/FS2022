#include <iostream>
#include <math.h>
#include "stack.h"

using namespace std;

//Run File in Terminal!!!

int main()
{
    int choice;
    int yesNo = 1;

    while (yesNo) {
        cout << "What would you like to test? Choos a number."<< endl;
        cout << "1   String" <<endl;
        cout << "2   Int" << endl;
        cout << "3   Double" << endl;
        cin >> choice;

        switch(choice){
        case 1:{
            cout << "You chose String:" << endl;
            string testString = "ABCDEFGHIGKLMNOPQRSTUVZ";
            Stack<string,15> stackString;

            for(int i = 0; i<15; i++){
                stackString.push(testString.substr(i, 2));
            }
            stackString.push(testString.substr(17, 2));
            stackString.print();
            stackString.peek();
            stackString.pop();
            stackString.peek();
            stackString.pop();
            stackString.print();

            cout << "Test Done." <<endl;
            cout << "Would you loke to test another Type?" <<endl;
            cout << "1 yes, 0 no." <<endl;
            cin >> yesNo;

            break;
        }
        case 2:{
            cout << "You chose Int:" << endl;

            Stack<int, 15> stackInt;

            for(int i = 0; i<15; i++){
                stackInt.push(static_cast<int>(i));
            }

            stackInt.push(999);
            stackInt.peek();
            stackInt.pop();
            stackInt.pop();
            stackInt.peek();
            stackInt.print();


            cout << "Test Done." <<endl;
            cout << "Would you loke to test another Type?" <<endl;
            cout << "1 yes, 0 no." <<endl;
            cin >> yesNo;
            break;
        }
        case 3:{
            cout << "You chose Double:" << endl;

            Stack<double, 15> stackDoub;

            for(int i = 0; i<15; i++){
                stackDoub.push(sqrt(i));
            }

            stackDoub.print();
            stackDoub.pop();
            stackDoub.peek();
            stackDoub.pop();
            stackDoub.pop();
            stackDoub.peek();
            stackDoub.print();

            cout << "Test Done." <<endl;
            cout << "Would you loke to test another Type?" <<endl;
            cout << "1 yes, 0 no." <<endl;
            cin >> yesNo;
            break;
        }
        default:
            cout << "Your choice was invalid." << endl;
            cout << "Would you like to try again?" <<endl;
            cout << "1 yes, 0 no." <<endl;


        }
    }



    return 0;
}
