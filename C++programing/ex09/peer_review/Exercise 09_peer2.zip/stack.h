#ifndef STACK_H
#define STACK_H

#include <iostream>
#include <string.h>
#include <array>
#include <string.h>

using namespace std;

template<typename T, size_t size>

class StackDef
{
protected:
    array<T,size> m_store;
    size_t m_top{0};

public:
    StackDef<T, size>(){}
    ~StackDef<T,size>(){}

    void push(T val){
        if(this->m_top == 15)
        {
            cout << "Stack overflow!" << endl;
        }
        else
        {
            cout << "Value to be added: " << val << endl;
            this->m_store[this->m_top++] = val;
        }
    }

    T pop(){
        if(this->isEmpty())
        {
            cout << "Storage is empty!" << endl;
        }
        else
        {
            T val = this->m_store[this->m_top-1];
            this->m_store[--this->m_top] = 0;
            cout << "Popped val: " << val << endl;
            return val;
        }

    }

    T peek(){
        cout << "Peeked val: " << this->m_store[this->m_top-1] << endl;
        return this->m_store[this->m_top-1];
    }

    bool isEmpty(){
        if(this->m_top >= -1){
            return true;
        }
        else
            return false;
    }

    void print(){
        cout << "-------------------Print-------------------" << endl;
        for(size_t i = 0; i<size; i++)
        {
            cout << "Stack " << i << ": " << this->m_store[i] << endl;
        }
        cout << "-------------------------------------------" << endl;

    }
};

template<typename T, size_t size>
class Stack : public StackDef<T,size>
{

};

template<size_t size>
class Stack<string, size> : public StackDef<string,size>
{
public:
    string pop(){
        string val = StackDef<string, size>::m_store[StackDef<string, size>::m_top-1];
        StackDef<string, size>::m_store[--StackDef<string, size>::m_top] = "";
        cout << "Popped val: " << val << endl;
        return val;
    }
};


#endif // STACK_H
